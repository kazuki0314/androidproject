package com.example.expirypal;

import android.content.ContentValues;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;
import com.example.expirypal.DatabaseHelper;

public class adddocument extends AppCompatActivity {

    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_document);

        dbHelper = new DatabaseHelper(this);

        Button addButton = findViewById(R.id.button7);
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addDocument();
            }
        });
    }

    private void addDocument() {
        EditText docNameEditText = findViewById(R.id.editTextText);
        EditText renewalDateEditText = findViewById(R.id.editTextText4);
        EditText reminderEditText = findViewById(R.id.editTextText5);
        EditText sendToEditText = findViewById(R.id.editTextText7);
        EditText docNumberEditText = findViewById(R.id.editTextNumber2);
        EditText noteEditText = findViewById(R.id.editTextText9);

        String docName = docNameEditText.getText().toString();
        String renewalDate = renewalDateEditText.getText().toString();
        String reminderDate = reminderEditText.getText().toString();
        String sendTo = sendToEditText.getText().toString();
        String docNumber = docNumberEditText.getText().toString();
        String note = noteEditText.getText().toString();

        // Insert document details into the database
        boolean success = dbHelper.addDocument(docName, renewalDate, reminderDate, sendTo, docNumber, note);

        if (success) {
            // Document added successfully, you can add further actions here if needed
            // For example, show a Toast message or navigate to another activity
        } else {
            // Failed to add document, handle the error accordingly
            // For example, show an error message
        }
    }
}