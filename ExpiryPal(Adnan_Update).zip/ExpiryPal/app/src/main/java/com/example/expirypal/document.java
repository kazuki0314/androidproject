package com.example.expirypal;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class DocumentActivity extends AppCompatActivity {
    private ListView docListView;
    private DatabaseHelper dbHelper;
    private ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.document_page);

        dbHelper = new DatabaseHelper(this);

        ImageButton docBackBtn = findViewById(R.id.docbackbtn);
        ImageButton docAddBtn = findViewById(R.id.docadd);
        EditText docSearchEditText = findViewById(R.id.docsearch);
        docListView = findViewById(R.id.docListView);

        docBackBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent homeIntent = new Intent(DocumentActivity.this, HomeActivity.class);
                startActivity(homeIntent);
            }
        });

        docAddBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent addDocumentIntent = new Intent(DocumentActivity.this, AddDocumentActivity.class);
                startActivity(addDocumentIntent);
            }
        });

        docSearchEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                adapter.getFilter().filter(s);
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        docListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String selectedDocumentDetails = adapter.getItem(position);

                Intent editDocumentIntent = new Intent(DocumentActivity.this, EditDocumentActivity.class);
                editDocumentIntent.putExtra("selectedDocumentDetails", selectedDocumentDetails);
                startActivity(editDocumentIntent);
            }
        });

        docListView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                showDeleteConfirmationDialog(position);
                return true;
            }
        });

        refreshDocumentList();
    }

    private void refreshDocumentList() {
        ArrayList<String> documentItemsWithDetails = new ArrayList<>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.query(DatabaseHelper.TABLE_NAME_DOCUMENTS,
                new String[]{DatabaseHelper.COLUMN_DOC_NAME, DatabaseHelper.COLUMN_EXPIRY_DATE, DatabaseHelper.COLUMN_CATEGORY, DatabaseHelper.COLUMN_NOTE},
                null, null, null, null, null);

        while (cursor.moveToNext()) {
            String docName = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_DOC_NAME));
            String expiryDate = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_EXPIRY_DATE));
            String category = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_CATEGORY));
            String note = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_NOTE));

            String details = "Document Name: " + docName +
                    "\nExpiry Date: " + expiryDate +
                    "\nCategory: " + category +
                    "\nNote: " + note;

            documentItemsWithDetails.add(details);
        }

        cursor.close();
        db.close();

        if (adapter == null) {
            adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, documentItemsWithDetails);
            docListView.setAdapter(adapter);
        } else {
            adapter.clear();
            adapter.addAll(documentItemsWithDetails);
            adapter.notifyDataSetChanged();
        }
    }

    private void showDeleteConfirmationDialog(final int position) {
        // Implement your delete confirmation dialog here
    }
}
